import datetime
import time
import boto3
import logging
import sys

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_from_timestamp():
    JST = datetime.timezone(datetime.timedelta(hours=+9), 'JST')
    TMP_TODAY = datetime.datetime.now(JST)
    TODAY = datetime.datetime(TMP_TODAY.year, TMP_TODAY.month, TMP_TODAY.day)
    TMP_DATE = TODAY - datetime.timedelta(days=1,hours=9)
    START_TIME = TMP_DATE - datetime.timedelta(days = 7)
    TIMESTAMP = time.mktime(START_TIME.timetuple())
    DESTINATION_PREFIX_YEAR = START_TIME.year
    DESTINATION_PREFIX_MONTH = START_TIME.month
    return TIMESTAMP, DESTINATION_PREFIX_YEAR, DESTINATION_PREFIX_MONTH

def get_to_timestamp(from_ts):
    return from_ts + ((60 * 60 * 24) * 7) - 1

def lambda_handler(event, context):
    FROM_RESULT = get_from_timestamp()
    from_ts = int(FROM_RESULT[0])
    to_ts = get_to_timestamp(from_ts)
    logger.info('Timestamp: from_ts %s, to_ts %s' % (from_ts, to_ts))

    TARGETLOGGROUPNAME = event['TargetLogGroupName']
    DESTINATIONS3BUCKETNAME = event['DestinationS3BucketName']
    DESTINATIONS3PREFIX = event['DestinationS3Prefix'] + '/'

    YEAR = str(FROM_RESULT[1]) + '/'
    
    if FROM_RESULT[2] < 10:
        MONTH = '0' + str(FROM_RESULT[2])
    else:
        MONTH = str(FROM_RESULT[2])


    client = boto3.client('logs')
    try:
        client.create_export_task(
            logGroupName      = TARGETLOGGROUPNAME,
            fromTime          = from_ts * 1000,
            to                = to_ts * 1000,
            destination       = DESTINATIONS3BUCKETNAME,
            destinationPrefix = DESTINATIONS3PREFIX + YEAR + MONTH
        )
    except:
        logger.error(sys.exc_info())