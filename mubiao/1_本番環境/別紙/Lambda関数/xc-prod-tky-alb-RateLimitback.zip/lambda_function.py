import json
import boto3

def lambda_handler(event, context):
    client = boto3.client('elbv2')

    #リスナールールの優先順位切替。表示順を標準状態に戻す
    responce = client.set_rule_priorities(
        RulePriorities=[
            {
                #流量制限時表示ルール:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 43
            },
            {
                #流量制限時表示ルール:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 43
            },
            {
                #BS1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 1
            },
            {
                #BS1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 1
            },
            {
                #BS2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 2
            },
            {
                #BS2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 2
            },
            {
                #BS3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 3
            },
            {
                #BS3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 3
            },
            {
                #CI1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 4
            },
            {
                #CI1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 4
            },
            {
                #CI2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 5
            },
            {
                #CI2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 5
            },
            {
                #CI3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 6
            },
            {
                #CI3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 6
            },
            {
                #CI4:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 7
            },
            {
                #CI4:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 7
            },
            {
                #FO1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 8
            },
            {
                #FO1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 8
            },
            {
                #FO2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 9
            },
            {
                #FO2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 9
            },
            {
                #FO3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 10
            },
            {
                #FO3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 10
            },
            {
                #SM1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 11
            },
            {
                #SM1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 11
            },
            {
                #SM2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 12
            },
            {
                #SM2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 12
            },
            {
                #SM3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 13
            },
            {
                #SM3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 13
            },
            {
                #SM4:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 14
            },
            {
                #SM4:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 14
            },
            {
                #api/BS1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 15
            },
            {
                #api/BS1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 15
            },
            {
                #api/BS2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 16
            },
            {
                #api/BS2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 16
            },
            {
                #api/BS3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 17
            },
            {
                #api/BS3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 17
            },
            {
                #api/CI1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 18
            },
            {
                #api/CI1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 18
            },
            {
                #api/CI2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 19
            },
            {
                #api/CI2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 19
            },
            {
                #api/CI3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 20
            },
            {
                #api/CI3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 20
            },
            {
                #api/CI4:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 21
            },
            {
                #api/CI4:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 21
            },
            {
                #api/FO1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 22
            },
            {
                #api/FO1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 22
            },
            {
                #api/FO2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 23
            },
            {
                #api/FO2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 23
            },
            {
                #api/FO3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 24
            },
            {
                #api/FO3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 24
            },
            {
                #api/SM1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 25
            },
            {
                #api/SM1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 25
            },
            {
                #api/SM2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 26
            },
            {
                #api/SM2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 26
            },
            {
                #api/SM3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 27
            },
            {
                #api/SM3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 27
            },
            {
                #api/SM4:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 28
            },
            {
                #api/SM4:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 28
            },
            {
                #ddb/BS1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 29
            },
            {
                #ddb/BS1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 29
            },
            {
                #ddb/BS2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 30
            },
            {
                #ddb/BS2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 30
            },
            {
                #ddb/BS3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 31
            },
            {
                #ddb/BS3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 31
            },
            {
                #ddb/CI1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 32
            },
            {
                #ddb/CI1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 32
            },
            {
                #ddb/CI2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 33
            },
            {
                #ddb/CI2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 33
            },
            {
                #ddb/CI3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 34
            },
            {
                #ddb/CI3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 34
            },
            {
                #ddb/CI4:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 35
            },
            {
                #ddb/CI4:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 35
            },
            {
                #ddb/FO1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 36
            },
            {
                #ddb/FO1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 36
            },
            {
                #ddb/FO2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 37
            },
            {
                #ddb/FO2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 37
            },
            {
                #ddb/FO3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 38
            },
            {
                #ddb/FO3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 38
            },
            {
                #ddb/SM1:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 39
            },
            {
                #ddb/SM1:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 39
            },
            {
                #ddb/SM2:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 40
            },
            {
                #ddb/SM2:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 40
            },
            {
                #ddb/SM3:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 41
            },
            {
                #ddb/SM3:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 41
            },
            {
                #ddb/SM4:80
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 42
            },
            {
                #ddb/SM4:443
                'RuleArn': 'arn:aws:elasticloadbalancing:ap-northeast-1:<AWSアカウントID>:listener-rule/app/<ALBのARN>/<リスナールールのARN>',
                'Priority': 42
            },
        ]
    )
    
    # 変更後の設定を表示
    result1 = client.describe_rules(
        ListenerArn='<ポート80のリスナーARN>',
    )

    result2 = client.describe_rules(
        ListenerArn='<ポート443のリスナーARN>',
    )
    return result1,result2