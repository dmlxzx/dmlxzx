import datetime
def set_csv(DATA):
  JST = datetime.timezone(datetime.timedelta(hours=+9), 'JST')
  TIMESTAMP = DATA["Timestamp"].astimezone(JST)
  AVERAGE = DATA["Average"]
  MAXIMUM = DATA["Maximum"]
  MINIMUM = DATA["Minimum"]
  SUM = DATA["Sum"]
  SAMPLECOUNT = DATA["SampleCount"]
  UNIT = DATA["Unit"]
  CSV = ""
  CSV = CSV + str("\n")
  CSV = CSV + str(TIMESTAMP) + ","
  CSV = CSV + str(AVERAGE) + ","
  CSV = CSV + str(MAXIMUM) + ","
  CSV = CSV + str(MINIMUM) + ","
  CSV = CSV + str(SUM) + ","
  CSV = CSV + str(SAMPLECOUNT) + ","
  CSV = CSV + str(UNIT)
  return CSV
