import boto3
import datetime
import format_csv
import csv
import operator
import json

def ec2_cpu_metric_statistics(SERVICE, TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET):
  CLOUDWATCH = boto3.client("cloudwatch")
  S3 = boto3.resource("s3")
  EC2 = boto3.client("ec2")
  with open("ec2_ids.json", "rb") as fin:
    IDS = json.load(fin)
  for ID in IDS:
    INSTANCE_ID = EC2.describe_instances(Filters=[{"Name":"tag:Name","Values":[ID["InstanceName"]]}])["Reservations"][0]["Instances"][0]["InstanceId"]
    RESPONSE = CLOUDWATCH.get_metric_statistics(
      Namespace="AWS/EC2",
      MetricName="CPUUtilization",
      Dimensions=[
        {
          'Name': "InstanceId",
          'Value': INSTANCE_ID
        }
      ],
      StartTime=START_TIME,
      EndTime=END_TIME,
      Period=60,
      Statistics=[
        'SampleCount',
        'Average',
        'Sum',
        'Minimum',
        'Maximum'
      ],
      Unit="Percent"
    )
    OBJECT_NAME = str(datetime.datetime.strftime(YESTERDAY, "%Y")) + str(datetime.datetime.strftime(YESTERDAY, "%m")) + str(datetime.datetime.strftime(YESTERDAY, "%d")) + "_CPUUtilization" + ".csv"
    OBJECT = S3.Object(S3_BUCKET, "CloudWatchMetrics/" + SERVICE + "/" + ID["HostName"] + "/" + str(datetime.datetime.strftime(YESTERDAY, "%Y")) + "/" + str(datetime.datetime.strftime(YESTERDAY, "%m")) + "/" + OBJECT_NAME)
    CSV = ""
    for DATAPOINT in RESPONSE["Datapoints"]:
      CSV = CSV + format_csv.set_csv(DATAPOINT)
    SORT_CSV = sorted(csv.reader(CSV.strip().splitlines()), key=operator.itemgetter(0))
    SORT_CSV.insert(0, ["Timestamp","Average","Maximum","Minimum","Sum","SampleCount","Unit"])
    SEND_DATA = ""
    for STR in SORT_CSV:
      SEND_DATA = SEND_DATA + ",".join(STR) + str("\n")
    OBJECT.put(Body = SEND_DATA)

def ec2_memory_metric_statistics(SERVICE, TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET):
  CLOUDWATCH = boto3.client("cloudwatch")
  S3 = boto3.resource("s3")
  with open("ec2_ids.json", "rb") as fin:
    IDS = json.load(fin)
  for ID in IDS:
    RESPONSE = CLOUDWATCH.get_metric_statistics(
      Namespace="CWAgent",
      MetricName="Memory % Committed Bytes In Use",
      Dimensions=[
        {
          'Name': 'host',
          'Value': ID['HostName']
        },
        {
          'Name': 'objectname',
          'Value': 'Memory'
        }
      ],
      StartTime=START_TIME,
      EndTime=END_TIME,
      Period=60,
      Statistics=[
        'SampleCount',
        'Average',
        'Sum',
        'Minimum',
        'Maximum'
      ],
      Unit="Percent"
    )
    OBJECT_NAME = str(datetime.datetime.strftime(YESTERDAY, "%Y")) + str(datetime.datetime.strftime(YESTERDAY, "%m")) + str(datetime.datetime.strftime(YESTERDAY, "%d")) + "_MemoryUtilization" + ".csv"
    OBJECT = S3.Object(S3_BUCKET, "CloudWatchMetrics/" + SERVICE + "/" + ID["HostName"] + "/" + str(datetime.datetime.strftime(YESTERDAY, "%Y")) + "/" + str(datetime.datetime.strftime(YESTERDAY, "%m")) + "/" + OBJECT_NAME)
    CSV = ""
    for DATAPOINT in RESPONSE["Datapoints"]:
      CSV = CSV + format_csv.set_csv(DATAPOINT)
    SORT_CSV = sorted(csv.reader(CSV.strip().splitlines()), key=operator.itemgetter(0))
    SORT_CSV.insert(0, ["Timestamp","Average","Maximum","Minimum","Sum","SampleCount","Unit"])
    SEND_DATA = ""
    for STR in SORT_CSV:
      SEND_DATA = SEND_DATA + ",".join(STR) + str("\n")
    OBJECT.put(Body = SEND_DATA)

def ec2_disk_metric_statistics(SERVICE, TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET):
  CLOUDWATCH = boto3.client("cloudwatch")
  S3 = boto3.resource("s3")
  with open("ec2_ids.json", "rb") as fin:
    IDS = json.load(fin)
  for ID in IDS:
    for DEVICE in ID["Devicename"]:
      RESPONSE = CLOUDWATCH.get_metric_statistics(
        Namespace="CWAgent",
        MetricName="LogicalDisk % Free Space",
        Dimensions=[
          {
            'Name': 'host',
            'Value': ID['HostName']
          },
          {
            'Name': 'objectname',
            'Value': 'LogicalDisk'
          },
          {
            'Name': 'instance',
            'Value': DEVICE
          }
        ],
        StartTime=START_TIME,
        EndTime=END_TIME,
        Period=60,
        Statistics=[
          'SampleCount',
          'Average',
          'Sum',
          'Minimum',
          'Maximum'
        ],
        Unit="Percent"
      )
      OBJECT_NAME = str(datetime.datetime.strftime(YESTERDAY, "%Y")) + str(datetime.datetime.strftime(YESTERDAY, "%m")) + str(datetime.datetime.strftime(YESTERDAY, "%d")) + "_" + str(DEVICE) + "DiskUtilization" + ".csv"
      OBJECT = S3.Object(S3_BUCKET, "CloudWatchMetrics/" + SERVICE + "/" + ID["HostName"] + "/" + str(datetime.datetime.strftime(YESTERDAY, "%Y")) + "/" + str(datetime.datetime.strftime(YESTERDAY, "%m")) + "/" + OBJECT_NAME)
      CSV = ""
      for DATAPOINT in RESPONSE["Datapoints"]:
        CSV = CSV + format_csv.set_csv(DATAPOINT)
      SORT_CSV = sorted(csv.reader(CSV.strip().splitlines()), key=operator.itemgetter(0))
      SORT_CSV.insert(0, ["Timestamp","Average","Maximum","Minimum","Sum","SampleCount","Unit"])
      SEND_DATA = ""
      for STR in SORT_CSV:
        SEND_DATA = SEND_DATA + ",".join(STR) + str("\n")
      OBJECT.put(Body = SEND_DATA)

def aurora_cluster_metric_statistics(SERVICE, TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET):
  CLOUDWATCH = boto3.client("cloudwatch")
  S3 = boto3.resource("s3")
  with open("aurora_ids.json", "rb") as fin:
    IDS = json.load(fin)
  for ID in IDS:
    RESPONSE = CLOUDWATCH.get_metric_statistics(
      Namespace="AWS/RDS",
      MetricName="VolumeBytesUsed",
      Dimensions=[
        {
          'Name': 'DBClusterIdentifier',
          'Value': ID['ClusterName']
        }
      ],
      StartTime=START_TIME,
      EndTime=END_TIME,
      Period=60,
      Statistics=[
        'SampleCount',
        'Average',
        'Sum',
        'Minimum',
        'Maximum'
      ],
      Unit="Bytes"
    )
    OBJECT_NAME = str(datetime.datetime.strftime(YESTERDAY, "%Y")) + str(datetime.datetime.strftime(YESTERDAY, "%m")) + str(datetime.datetime.strftime(YESTERDAY, "%d")) + "_VolumeBytesUsed" + ".csv"
    OBJECT = S3.Object(S3_BUCKET, "CloudWatchMetrics/" + SERVICE + "/" + ID["ClusterName"] + "/" + str(datetime.datetime.strftime(YESTERDAY, "%Y")) + "/" + str(datetime.datetime.strftime(YESTERDAY, "%m")) + "/" + OBJECT_NAME)
    CSV = ""
    for DATAPOINT in RESPONSE["Datapoints"]:
      CSV = CSV + format_csv.set_csv(DATAPOINT)
    SORT_CSV = sorted(csv.reader(CSV.strip().splitlines()), key=operator.itemgetter(0))
    SORT_CSV.insert(0, ["Timestamp","Average","Maximum","Minimum","Sum","SampleCount","Unit"])
    SEND_DATA = ""
    for STR in SORT_CSV:
      SEND_DATA = SEND_DATA + ",".join(STR) + str("\n")
    OBJECT.put(Body = SEND_DATA)

def aurora_instance_metric_statistics(SERVICE, TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET):
  CLOUDWATCH = boto3.client("cloudwatch")
  S3 = boto3.resource("s3")
  INSTANCE_METRICS = [ { "MetricName": "CPUUtilization", "Unit": "Percent" }, { "MetricName": "FreeableMemory", "Unit": "Bytes" } ]
  with open("aurora_ids.json", "rb") as fin:
    IDS = json.load(fin)
  for ID in IDS:
    for INSTANCE in ID["InstanceName"]:
      for INSTANCE_METRIC in INSTANCE_METRICS:
        RESPONSE = CLOUDWATCH.get_metric_statistics(
          Namespace="AWS/RDS",
          MetricName=INSTANCE_METRIC["MetricName"],
          Dimensions=[
            {
              'Name': 'DBInstanceIdentifier',
              'Value': INSTANCE
            }
          ],
          StartTime=START_TIME,
          EndTime=END_TIME,
          Period=60,
          Statistics=[
            'SampleCount',
            'Average',
            'Sum',
            'Minimum',
            'Maximum'
          ],
          Unit=INSTANCE_METRIC["Unit"]
        )
        OBJECT_NAME = str(datetime.datetime.strftime(YESTERDAY, "%Y")) + str(datetime.datetime.strftime(YESTERDAY, "%m")) + str(datetime.datetime.strftime(YESTERDAY, "%d")) + "_" + INSTANCE_METRIC["MetricName"] + ".csv"
        OBJECT = S3.Object(S3_BUCKET, "CloudWatchMetrics/" + SERVICE + "/" + ID["ClusterName"] + "/" + INSTANCE + "/" + str(datetime.datetime.strftime(YESTERDAY, "%Y")) + "/" + str(datetime.datetime.strftime(YESTERDAY, "%m")) + "/" + OBJECT_NAME)
        CSV = ""
        for DATAPOINT in RESPONSE["Datapoints"]:
          CSV = CSV + format_csv.set_csv(DATAPOINT)
        SORT_CSV = sorted(csv.reader(CSV.strip().splitlines()), key=operator.itemgetter(0))
        SORT_CSV.insert(0, ["Timestamp","Average","Maximum","Minimum","Sum","SampleCount","Unit"])
        SEND_DATA = ""
        for STR in SORT_CSV:
          SEND_DATA = SEND_DATA + ",".join(STR) + str("\n")
        OBJECT.put(Body = SEND_DATA)

def redis_metric_statistics(SERVICE, TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET):
  CLOUDWATCH = boto3.client("cloudwatch")
  S3 = boto3.resource("s3")
  METRICS = [ { "MetricName": "CPUUtilization", "Unit": "Percent" }, { "MetricName": "FreeableMemory", "Unit": "Bytes" } ]
  with open("redis_ids.json", "rb") as fin:
    IDS = json.load(fin)
  for ID in IDS:
    for METRIC in METRICS:
      RESPONSE = CLOUDWATCH.get_metric_statistics(
        Namespace="AWS/ElastiCache",
        MetricName=METRIC["MetricName"],
        Dimensions=[
          {
            'Name': 'CacheClusterId',
            'Value': ID['CacheClusterId']
          },
          {
            'Name': 'CacheNodeId',
            'Value': ID['CacheNodeId']
          }
        ],
        StartTime=START_TIME,
        EndTime=END_TIME,
        Period=60,
        Statistics=[
          'SampleCount',
          'Average',
          'Sum',
          'Minimum',
          'Maximum'
        ],
        Unit=METRIC["Unit"]
      )
      OBJECT_NAME = str(datetime.datetime.strftime(YESTERDAY, "%Y")) + str(datetime.datetime.strftime(YESTERDAY, "%m")) + str(datetime.datetime.strftime(YESTERDAY, "%d")) + "_" + METRIC["MetricName"] + ".csv"
      OBJECT = S3.Object(S3_BUCKET, "CloudWatchMetrics/" + SERVICE + "/" + ID["CacheClusterId"] + str(datetime.datetime.strftime(YESTERDAY, "%Y")) + "/" + str(datetime.datetime.strftime(YESTERDAY, "%m")) + "/" + OBJECT_NAME)
      CSV = ""
      for DATAPOINT in RESPONSE["Datapoints"]:
        CSV = CSV + format_csv.set_csv(DATAPOINT)
      SORT_CSV = sorted(csv.reader(CSV.strip().splitlines()), key=operator.itemgetter(0))
      SORT_CSV.insert(0, ["Timestamp","Average","Maximum","Minimum","Sum","SampleCount","Unit"])
      SEND_DATA = ""
      for STR in SORT_CSV:
        SEND_DATA = SEND_DATA + ",".join(STR) + str("\n")
      OBJECT.put(Body = SEND_DATA)
