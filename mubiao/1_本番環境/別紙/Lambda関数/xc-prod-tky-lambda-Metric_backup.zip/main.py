import os
import datetime
import logging
import sys
import get_metric_statistics

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
  JST = datetime.timezone(datetime.timedelta(hours=+9), 'JST')
  TMP_TODAY = datetime.datetime.now(JST)
  TODAY = datetime.datetime(TMP_TODAY.year, TMP_TODAY.month, TMP_TODAY.day)
  YESTERDAY = TODAY - datetime.timedelta(days=1)
  START_TIME = TODAY - datetime.timedelta(days=1,hours=9)
  END_TIME = TODAY - datetime.timedelta(days=1) + datetime.timedelta(hours=14,minutes=59,seconds=59)
  S3_BUCKET = str(os.environ["S3"])
  logger.info("AWSService: " + event["ServiceName"] )
  logger.info("Period: " + str(START_TIME) + "~" + str(END_TIME) )

  try:
    if event["ServiceName"] == "EC2":
      get_metric_statistics.ec2_cpu_metric_statistics(event["ServiceName"], TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET)
      get_metric_statistics.ec2_memory_metric_statistics(event["ServiceName"], TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET)
      get_metric_statistics.ec2_disk_metric_statistics(event["ServiceName"], TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET)
    elif event["ServiceName"] == "Aurora":
      get_metric_statistics.aurora_cluster_metric_statistics(event["ServiceName"], TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET)
      get_metric_statistics.aurora_instance_metric_statistics(event["ServiceName"], TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET)
    else:
      get_metric_statistics.redis_metric_statistics(event["ServiceName"], TODAY, YESTERDAY, START_TIME, END_TIME, S3_BUCKET)
  except:
    logger.error(sys.exc_info())

